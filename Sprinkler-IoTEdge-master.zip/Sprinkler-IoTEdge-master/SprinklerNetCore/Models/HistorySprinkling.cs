﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SprinklerNetCore.Models
{
    public class HistorySprinkling
    {
        public List<SprinklerProgram> SprinklerPrograms { get; set; }
    }
}
