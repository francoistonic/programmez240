﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SprinklerNetCore.Models
{
    public class AzureLog
    {
        public object Info { get; set; }
        public string DeviceId { get; set; }
    }
}
